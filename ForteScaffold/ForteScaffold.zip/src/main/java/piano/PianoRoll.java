package piano;

import processing.core.PApplet;
import processing.core.PImage;
import java.util.ArrayList;
import java.util.List;
import java.util.Arrays;
import javax.sound.midi.*;

public class PianoRoll{

    private int x;
    private int y;

    //private int blockX;
    //private int blockY;

    private PImage grid;
    private PImage block;

    private Synthesizer synth;
    private MidiChannel[] midiChannel;
    private Instrument[] instrument;
    private boolean successLoadInstrument;

    //private Sequencer seq;

    private int[] velocity;

    private List<int[]> blockXY;

    private List<Boolean> pianoGrid;

    public PianoRoll(int x,int y,PImage grid,PImage block){
        this.x = x;
        this.y = y;
        
        this.blockXY = new ArrayList<int[]>();

        this.pianoGrid = new ArrayList<Boolean>();

        this.grid = grid;
        this.block = block;
        try{
            this.synth = MidiSystem.getSynthesizer();
            this.synth.open();
            this.midiChannel = this.synth.getChannels();
            this.instrument = this.synth.getDefaultSoundbank().getInstruments();
            this.successLoadInstrument = this.synth.loadInstrument(instrument[0]);
        }catch(MidiUnavailableException Exception){
            System.out.println("uh oh");
        }

        this.velocity = new int[13];
        for(int i = 0;i<this.velocity.length;i++){
            this.velocity[i] = 0;
        }
    }

    public static boolean arrayListContains(List<int[]> list, int[] list2) {
        //if (list.size() != list2.size()) return false;
        for (int i = 0; i < list.size(); i++){
            if (Arrays.equals(list.get(i), list2)) return true;
        }
        return false;
    }

    public static boolean arrayListRemove(List<int[]> list, int[] list2) {

        int index = -1;
        for (int i = 0; i < list.size(); i++){
            if (Arrays.equals(list.get(i), list2)){
                index = i;
            }
        }
        if(index!=-1){
            list.remove(index);
            return true;
        }else{
            return false;
        }
        
    }


    public void check(PApplet app){
        int countX = 0;
        int countY = 0;

        for(int i=60;i<540;i+=15){
            for(int j=75;j<335;j+=20){

                if(app.mouseX > i && app.mouseX < i+15 && app.mouseY > j && app.mouseY < j+20){
                    int[] coord = {i,j};
                    if(this.arrayListContains(this.blockXY,coord)){
                        this.arrayListRemove(this.blockXY,coord);
                        //remove from piano sequence
                    }else{
                        this.blockXY.add(coord);
                        //add to piano sequence
                    }
                }
                countY++;
            }



            countX++;
        }
    }
    
    public void play(){
        
        //Synthesizer synth = MidiSystem.getSynthesizer();
        //Sequencer seq = MidiSystem.getSequencer();
        //synth.open();
        //MidiChannel[] midiChannel = this.synth.getChannels();
        //Instrument[] instrument = this.synth.getDefaultSoundbank().getInstruments();
        //boolean successLoadInstrument = this.synth.loadInstrument(instrument[0]);

        //for(int i = 0;i < this.blockXY.size();i++){
            //int[] coord = this.blockXY.get(i);
            //if(x == coord[0] && coord[1] == 75){
                //midiChannel[0].noteOn(72,this.velocity);

            //}
        //}
        //for(int i = 0;i < this.velocity.length;i++){
        midiChannel[0].noteOn(72,this.velocity[0]);
        //}

        
    }

    public void tick(int x){
        
        if(this.blockXY.size() == 0){
            return;
        }
        //for(int i = 0;i < this.blockXY.size();i++){
            //int[] coord = this.blockXY.get(i);
            //for(int j = 75;j < 335;i+=20){
            //if(x == coord[0] && coord[1] == 75){
                //int index = (j-75)/20;
                //if(this.velocity[0] == 90){
                    //this.velocity[0] = 0;
                //}else{
                    //this.velocity[0] = 90;
                //}
                //this.velocity[0] = 90;
            //}   
            //}
        //}

        int[] coord = {x,75};

        if(this.arrayListContains(this.blockXY,coord)){
            if(this.velocity[0] == 0){
                this.velocity[0] = 90;
            }else{
                this.velocity[0] = 0;
            }
        }
        
    }

    public void draw(PApplet app){
        app.image(this.grid,this.x,this.y);

        for(int i = 0;i<this.blockXY.size();i++){
            int[] coord = new int[2];
            coord=this.blockXY.get(i);
            app.image(this.block,coord[0],coord[1]);

        }
    }
}