package piano;

import processing.core.PApplet;
import processing.core.PImage;
import javax.sound.midi.*;

public class PlayButton{

    private int x;
    private int y;

    private boolean paused;

    private PImage play;
    private PImage pause;
    private PImage current;
    private PImage buttonBack;

    public PlayButton(int x, int y, PImage sprite1, PImage sprite2, PImage sprite3){
        this.x = x;
        this.y = y;

        this.paused = true;
        
        this.play = sprite1;
        this.pause = sprite2;
        this.buttonBack = sprite3;

        this.current = this.play;
    }

    public void tick(){

    }

    public void draw(PApplet app){
        app.image(this.buttonBack,this.x,this.y);
        app.image(this.current,this.x,this.y);
    }

    public void playPause(){
        this.paused = !this.paused;

        if(this.current == this.play){
            this.current = this.pause;
        }else if(this.current == this.pause){
            this.current = this.play;
        }
        
    }

    public void playStop(){
        this.current = this.play;
    }
}