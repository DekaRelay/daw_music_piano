package piano;

import processing.core.PApplet;
import processing.core.PImage;
import javax.sound.midi.*;

public class App extends PApplet {

    private PianoRoll piano;
    private Pointer pointer;
    private PlayButton play;
    private StopButton stop;

    private PImage banner;
    private PImage middleBanner;
    private PImage keyboard;
    


    public App() {
        // Initialise variables here
    }

    public void settings() {
        // Don't touch
        size(540, 335);
    }

    public void setup() {
        frameRate(60);
        // Load images here
        

        this.piano = new PianoRoll(60,75,this.loadImage("src/main/resources/grid.png"),this.loadImage("src/main/resources/block.png"));
        this.pointer = new Pointer(48,59,this.loadImage("src/main/resources/pointer.png"));
        this.play = new PlayButton(5,5,this.loadImage("src/main/resources/play.png"),this.loadImage("src/main/resources/pause.png"),this.loadImage("src/main/resources/buttonBack.png"));
        this.stop = new StopButton(50,5,this.loadImage("src/main/resources/stop.png"),this.loadImage("src/main/resources/buttonBack.png"));


        this.banner = this.loadImage("src/main/resources/banner.png");
        this.keyboard = this.loadImage("src/main/resources/keyboard.png");
        this.middleBanner = this.loadImage("src/main/resources/middleBanner.png");

    }

    public void draw() {
        // Draw your program here
        this.play.tick();
        this.stop.tick();
        //this.piano.tick(this.pointer.x);
        //if((this.pointer.returnX()-60)%15 == 0){
        this.piano.tick(this.pointer.returnX());
            //this.piano.play();
        //}
        
        this.pointer.tick(this.piano);


        this.rect(0,0,550,345);

        this.image(this.middleBanner,0,0);
        this.image(this.banner,0,0);
        this.image(this.keyboard,0,75);

        //this.play.tick();
        this.play.draw(this);

        //this.stop.tick();
        this.stop.draw(this);

        //this.piano.tick();
        this.piano.draw(this);

        //this.pointer.tick();
        this.pointer.draw(this);

        
    }

    public void mousePressed(){
        if(mouseX > 5 && mouseX < 45 && mouseY > 5 && mouseY < 45){ //Play/pause button
    
            this.play.playPause();
            this.pointer.activate();
        }else if(mouseX > 50 && mouseX < 90 && mouseY > 5 && mouseY < 45){  //Stop button

            this.stop.stop(this.pointer,this.play,this.piano);
        }else if(mouseX > 60 && mouseX < 540 && mouseY > 75 && mouseY < 335){  //Piano roll grid

            this.piano.check(this);
        }
    }


    public static void main(String[] args) {
        // Don't touch this
        PApplet.main("piano.App");
    }
}
