package piano;

import processing.core.PApplet;
import processing.core.PImage;
import javax.sound.midi.*;

public class Pointer{

    private int x;
    private int y;

    private boolean active;
    private int vel;

    private PImage sprite;

    public Pointer(int x,int y,PImage sprite){
        this.x = x;
        this.y = y;

        this.active = false;
        this.vel = 1;

        this.sprite = sprite;
    }

    public void tick(PianoRoll piano){
        //handles logic
        //this.x+=this.vel;

        if(this.active){
            this.x+=this.vel;
            if((this.x)%15 == 0){
                piano.play();
            }

            if(this.x > 528){
                this.x = 48;
            }
        }

    }

    public void draw(PApplet app){
        //handles graphics
        app.image(this.sprite,this.x,this.y);
        app.line(60,75,60,335);
        app.stroke(255);
    }

    public void activate(){
        this.active = !this.active;
        //this.vel = 4;
    }

    public void reset(){
        this.x = 48;
        this.active = false;
    }

    public int returnX(){
        return this.x;
    }

}