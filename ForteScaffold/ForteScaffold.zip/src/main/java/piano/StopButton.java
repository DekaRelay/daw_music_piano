package piano;

import processing.core.PApplet;
import processing.core.PImage;
import javax.sound.midi.*;

public class StopButton{

    private int x;
    private int y;

    private PImage stop;
    private PImage buttonBack;

    public StopButton(int x, int y, PImage stop, PImage buttonBack){
        this.x = x;
        this.y = y;

        this.stop = stop;
        this.buttonBack = buttonBack;
    }

    public void tick(){

    }

    public void draw(PApplet app){
        app.image(this.buttonBack,this.x,this.y);
        app.image(this.stop,this.x,this.y);

    }

    public void stop(Pointer point, PlayButton play, PianoRoll piano){
        point.reset();
        play.playStop();

    }
}